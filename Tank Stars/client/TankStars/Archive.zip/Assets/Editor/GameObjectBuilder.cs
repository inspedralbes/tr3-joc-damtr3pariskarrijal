using System;
using System.IO;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.UIElements;

[Serializable]
public class SceneSpec
{
    public string sceneName;
    public string uxmlPath;
    public string managerScriptPath;
    public bool createGameManager;
}

public class GameObjectBuilder : EditorWindow
{
    private PanelSettings panelSettings;

    private static readonly SceneSpec[] SceneCatalog = new[]
    {
        new SceneSpec
        {
            sceneName = "LoginScene",
            uxmlPath = "Assets/UI/UXML/LoginScreen.uxml",
            managerScriptPath = "Assets/Scripts/AuthManager.cs",
            createGameManager = true
        },
        new SceneSpec
        {
            sceneName = "MenuScene",
            uxmlPath = "Assets/UI/UXML/MenuScreen.uxml",
            managerScriptPath = "Assets/Scripts/MenuManager.cs",
            createGameManager = false
        },
        new SceneSpec
        {
            sceneName = "WaitingScene",
            uxmlPath = "Assets/UI/UXML/WaitingScreen.uxml",
            managerScriptPath = "Assets/Scripts/WaitingManager.cs",
            createGameManager = false
        },
    };

    [MenuItem("Tools/GameObject Builder")]
    public static void ShowWindow()
    {
        GetWindow<GameObjectBuilder>("GameObject Builder");
    }

    void OnEnable()
    {
        panelSettings = AssetDatabase.LoadAssetAtPath<PanelSettings>("Assets/New Panel Settings.asset");
    }

    void OnGUI()
    {
        EditorGUILayout.LabelField("Scene Builder", EditorStyles.boldLabel);
        panelSettings = (PanelSettings)EditorGUILayout.ObjectField("Panel Settings", panelSettings, typeof(PanelSettings), false);

        EditorGUILayout.Space();
        if (GUILayout.Button("Build UI Scenes"))
        {
            if (!ValidateDependencies()) return;
            foreach (var spec in SceneCatalog)
            {
                CreateScene(spec);
            }
            AssetDatabase.SaveAssets();
            Debug.Log("Scene creation complete. Add them to Build Settings.");
        }
    }

    bool ValidateDependencies()
    {
        if (panelSettings == null)
        {
            Debug.LogError("Assign a PanelSettings asset before generating scenes.");
            return false;
        }

        foreach (var spec in SceneCatalog)
        {
            if (!File.Exists(spec.uxmlPath))
            {
                Debug.LogError($"UXML not found at {spec.uxmlPath}. Create the document first.");
                return false;
            }

            if (!File.Exists(spec.managerScriptPath))
            {
                Debug.LogError($"Script not found at {spec.managerScriptPath}. Create the script before generating scenes.");
                return false;
            }
        }

        return true;
    }

    void CreateScene(SceneSpec spec)
    {
        string sceneFolder = "Assets/Scenes";
        if (!Directory.Exists(sceneFolder))
        {
            Directory.CreateDirectory(sceneFolder);
        }

        string scenePath = $"{sceneFolder}/{spec.sceneName}.unity";
        var scene = EditorSceneManager.NewScene(NewSceneSetup.EmptyScene, NewSceneMode.Single);

        var root = new GameObject("UI Root");
        var document = root.AddComponent<UIDocument>();
        document.panelSettings = panelSettings;
        document.visualTreeAsset = AssetDatabase.LoadAssetAtPath<VisualTreeAsset>(spec.uxmlPath);
        if (document.visualTreeAsset == null)
        {
            Debug.LogError($"Failed to load VisualTreeAsset at {spec.uxmlPath}.");
            return;
        }

        var manager = CreateManagerComponent(spec.managerScriptPath, root);
        if (manager == null)
        {
            Debug.LogError($"Could not add manager for {spec.sceneName}. Skipping scene save.");
            return;
        }

        if (spec.createGameManager)
        {
            var gm = new GameObject("GameManager");
            gm.AddComponent<GameManager>();
            EditorSceneManager.MoveGameObjectToScene(gm, scene);
        }

        EditorSceneManager.MoveGameObjectToScene(root, scene);
        EditorSceneManager.SaveScene(scene, scenePath);
    }

    Component CreateManagerComponent(string scriptPath, GameObject root)
    {
        var monoScript = AssetDatabase.LoadAssetAtPath<MonoScript>(scriptPath);
        if (monoScript == null)
        {
            Debug.LogError($"MonoScript not found at {scriptPath}.");
            return null;
        }

        var scriptClass = monoScript.GetClass();
        if (scriptClass == null || !typeof(MonoBehaviour).IsAssignableFrom(scriptClass))
        {
            Debug.LogError($"Script at {scriptPath} does not derive from MonoBehaviour.");
            return null;
        }

        return root.AddComponent(scriptClass);
    }
}
