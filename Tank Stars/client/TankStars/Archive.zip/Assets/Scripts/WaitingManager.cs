using UnityEngine;
using UnityEngine.UIElements;
using UnityEngine.SceneManagement;
using UnityEngine.Networking;
using System.Collections;

public class WaitingManager : MonoBehaviour
{
    private string apiUrl = "http://localhost/api";

    private Label roomCodeText;
    private Label player2Status;
    private Button backBtn;

    void OnEnable()
    {
        var document = GetComponent<UIDocument>();
        if (document == null)
        {
            Debug.LogError("WaitingManager requires a UIDocument on the same GameObject.");
            enabled = false;
            return;
        }

        if (GameManager.Instance == null)
        {
            Debug.LogError("WaitingManager needs GameManager.Instance to be initialized before opening WaitingScene.");
            enabled = false;
            return;
        }

        var root = document.rootVisualElement;
        roomCodeText  = root.Q<Label>("room-code-text");
        player2Status = root.Q<Label>("player2-status");
        backBtn       = root.Q<Button>("back-btn");

        if (roomCodeText != null)
        {
            roomCodeText.text = GameManager.Instance.roomCode;
        }

        if (backBtn != null)
        {
            backBtn.clicked += OnBackClick;
        }

        var gameId = GameManager.Instance.gameId;
        if (gameId <= 0)
        {
            Debug.LogWarning("WaitingManager opened before a game was created; no poll will run.");
            if (player2Status != null)
            {
                player2Status.text = "Unable to poll for players because no game was created.";
            }
            return;
        }

        StartCoroutine(PollForPlayer(gameId));
    }

    void OnDisable()
    {
        StopAllCoroutines();
        if (backBtn != null)
        {
            backBtn.clicked -= OnBackClick;
        }
    }

    IEnumerator PollForPlayer(int initialGameId)
    {
        while (true)
        {
            yield return new WaitForSeconds(2f);

            var currentGameId = GameManager.Instance?.gameId ?? initialGameId;
            if (currentGameId <= 0)
            {
                Debug.LogError("Game id was lost while polling; stopping.");
                yield break;
            }

            UnityWebRequest req = UnityWebRequest.Get(
                apiUrl + "/games/" + currentGameId
            );
            yield return req.SendWebRequest();

            if (req.result == UnityWebRequest.Result.Success)
            {
                GameStatusResponse game = JsonUtility.FromJson<GameStatusResponse>(
                    req.downloadHandler.text
                );

                if (game.status == "in_progress")
                {
                    player2Status.RemoveFromClassList("status-text");
                    player2Status.AddToClassList("success-text");
                    player2Status.text = "✅  Player 2 joined! Starting...";
                    yield return new WaitForSeconds(1.5f);
                    SceneManager.LoadScene("CombatScene");
                    yield break;
                }
            }
        }
    }

    void OnBackClick()
    {
        StopAllCoroutines();
        SceneManager.LoadScene("MenuScene");
    }
}

[System.Serializable]
public class GameStatusResponse
{
    public int id;
    public string status;
    public string room_code;
}
