using UnityEngine;
using UnityEngine.UIElements;
using UnityEngine.SceneManagement;
using UnityEngine.Networking;
using System.Collections;

public class AuthManager : MonoBehaviour
{
    private string apiUrl = "http://localhost/api";

    private TextField usernameField;
    private TextField passwordField;
    private Label messageText;
    private Button loginBtn;
    private Button registerBtn;

    void OnEnable()
    {
        var root = GetComponent<UIDocument>().rootVisualElement;

        usernameField = root.Q<TextField>("username-field");
        passwordField = root.Q<TextField>("password-field");
        messageText   = root.Q<Label>("message-text");
        loginBtn      = root.Q<Button>("login-btn");
        registerBtn   = root.Q<Button>("register-btn");

        loginBtn.clicked    += () => StartCoroutine(Login());
        registerBtn.clicked += () => StartCoroutine(Register());
    }

    IEnumerator Register()
    {
        messageText.RemoveFromClassList("error-text");
        messageText.RemoveFromClassList("success-text");
        messageText.text = "Registering...";

        string json = "{\"username\":\"" + usernameField.value +
                      "\",\"password\":\"" + passwordField.value + "\"}";
        byte[] body = System.Text.Encoding.UTF8.GetBytes(json);

        UnityWebRequest req = new UnityWebRequest(apiUrl + "/auth/register", "POST");
        req.uploadHandler   = new UploadHandlerRaw(body);
        req.downloadHandler = new DownloadHandlerBuffer();
        req.SetRequestHeader("Content-Type", "application/json");

        yield return req.SendWebRequest();

        if (req.result == UnityWebRequest.Result.Success)
        {
            messageText.AddToClassList("success-text");
            messageText.text = "Account created! You can now log in.";
        }
        else
        {
            messageText.AddToClassList("error-text");
            messageText.text = "Username already exists.";
        }
    }

    IEnumerator Login()
    {
        messageText.RemoveFromClassList("error-text");
        messageText.RemoveFromClassList("success-text");
        messageText.text = "Logging in...";

        string json = "{\"username\":\"" + usernameField.value +
                      "\",\"password\":\"" + passwordField.value + "\"}";
        byte[] body = System.Text.Encoding.UTF8.GetBytes(json);

        UnityWebRequest req = new UnityWebRequest(apiUrl + "/auth/login", "POST");
        req.uploadHandler   = new UploadHandlerRaw(body);
        req.downloadHandler = new DownloadHandlerBuffer();
        req.SetRequestHeader("Content-Type", "application/json");

        yield return req.SendWebRequest();

        if (req.result == UnityWebRequest.Result.Success)
        {
            LoginResponse response = JsonUtility.FromJson<LoginResponse>(req.downloadHandler.text);
            GameManager.Instance.authToken = response.token;
            GameManager.Instance.playerId  = response.id;
            GameManager.Instance.username  = response.username;
            SceneManager.LoadScene("MenuScene");
        }
        else
        {
            messageText.AddToClassList("error-text");
            messageText.text = "Wrong username or password.";
        }
    }
}

[System.Serializable]
public class LoginResponse
{
    public string token;
    public int id;
    public string username;
}
