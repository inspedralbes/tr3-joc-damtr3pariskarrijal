using UnityEngine;
using UnityEngine.UIElements;
using UnityEngine.SceneManagement;
using UnityEngine.Networking;
using System.Collections;

public class MenuManager : MonoBehaviour
{
    private string apiUrl = "http://localhost/api";

    private Label welcomeText;
    private TextField roomCodeInput;
    private Label messageText;
    private Button createBtn;
    private Button joinBtn;
    private Button quitBtn;

    void OnEnable()
    {
        var root = GetComponent<UIDocument>().rootVisualElement;

        welcomeText   = root.Q<Label>("welcome-text");
        roomCodeInput = root.Q<TextField>("room-code-input");
        messageText   = root.Q<Label>("message-text");
        createBtn     = root.Q<Button>("create-btn");
        joinBtn       = root.Q<Button>("join-btn");
        quitBtn       = root.Q<Button>("quit-btn");

        welcomeText.text = "Welcome, " + GameManager.Instance.username + "!";

        createBtn.clicked += () => StartCoroutine(CreateGame());
        joinBtn.clicked   += () => StartCoroutine(JoinByCode());
        quitBtn.clicked   += () => Application.Quit();
    }

    IEnumerator CreateGame()
    {
        messageText.RemoveFromClassList("error-text");
        messageText.text = "Creating game...";

        string json = "{\"playerId\":" + GameManager.Instance.playerId + "}";
        byte[] body = System.Text.Encoding.UTF8.GetBytes(json);

        UnityWebRequest req = new UnityWebRequest(apiUrl + "/games", "POST");
        req.uploadHandler   = new UploadHandlerRaw(body);
        req.downloadHandler = new DownloadHandlerBuffer();
        req.SetRequestHeader("Content-Type", "application/json");

        yield return req.SendWebRequest();

        if (req.result == UnityWebRequest.Result.Success)
        {
            CreateGameResponse response = JsonUtility.FromJson<CreateGameResponse>(req.downloadHandler.text);
            GameManager.Instance.gameId   = response.gameId;
            GameManager.Instance.roomCode = response.roomCode;
            SceneManager.LoadScene("WaitingScene");
        }
        else
        {
            messageText.AddToClassList("error-text");
            messageText.text = "Could not create game. Is Docker running?";
        }
    }

    IEnumerator JoinByCode()
    {
        string code = roomCodeInput.value.Trim().ToUpper();
        if (code.Length == 0)
        {
            messageText.AddToClassList("error-text");
            messageText.text = "Please enter a room code.";
            yield break;
        }

        messageText.RemoveFromClassList("error-text");
        messageText.text = "Finding room...";

        UnityWebRequest findReq = UnityWebRequest.Get(apiUrl + "/games/room/" + code);
        yield return findReq.SendWebRequest();

        if (findReq.result != UnityWebRequest.Result.Success)
        {
            messageText.AddToClassList("error-text");
            messageText.text = "Room not found.";
            yield break;
        }

        GameResponse game = JsonUtility.FromJson<GameResponse>(findReq.downloadHandler.text);

        string json = "{\"playerId\":" + GameManager.Instance.playerId + "}";
        byte[] body = System.Text.Encoding.UTF8.GetBytes(json);

        UnityWebRequest joinReq = new UnityWebRequest(apiUrl + "/games/" + game.id + "/join", "POST");
        joinReq.uploadHandler   = new UploadHandlerRaw(body);
        joinReq.downloadHandler = new DownloadHandlerBuffer();
        joinReq.SetRequestHeader("Content-Type", "application/json");

        yield return joinReq.SendWebRequest();

        if (joinReq.result == UnityWebRequest.Result.Success)
        {
            GameManager.Instance.gameId   = game.id;
            GameManager.Instance.roomCode = code;
            SceneManager.LoadScene("WaitingScene");
        }
        else
        {
            messageText.AddToClassList("error-text");
            messageText.text = "Could not join. Room may be full.";
        }
    }
}

[System.Serializable]
public class CreateGameResponse
{
    public int gameId;
    public string roomCode;
}

[System.Serializable]
public class GameResponse
{
    public int id;
    public string room_code;
    public string status;
}
