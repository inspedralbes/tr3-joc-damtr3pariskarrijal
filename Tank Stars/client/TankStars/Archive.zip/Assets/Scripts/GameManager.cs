using UnityEngine;

public class GameManager : MonoBehaviour
{
    public static GameManager Instance;

    public string authToken;
    public int playerId;
    public string username;
    public int gameId;
    public string roomCode;

    void Awake()
    {
        if (Instance == null)
        {
            Instance = this;
            DontDestroyOnLoad(gameObject);
        }
        else
        {
            Destroy(gameObject);
        }
    }
}